<template>
  <div>121</div>
</template>
<script>
export default require('./pageDemo.js')
</script>
