<template>
  <div>121</div>
</template>
<script>
// export default require('./index.js')
</script>
